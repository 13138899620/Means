# activate-power-mode atom package
A work in progress package for Atom to replicate [codeinthedark/editor#1](https://github.com/codeinthedark/editor/pull/1) by popular demand.

Activate with <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>O</kbd> or through the command panel with `Activate Power Mode: Toggle`. In
this early version it only affects the current tab, to run it in a new tab you need to run `Window: Reload` first.

**NOTE THAT THIS VERSION IS VERY BUGGY RIGHT NOW**

![activate-power-mode](https://cloud.githubusercontent.com/assets/688415/11453297/b8f249ec-9605-11e5-978c-eb3bb21eecd8.gif)
